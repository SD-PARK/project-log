function validateForm() {
    const password = document.getElementById('password');
    const repeatPassword = document.getElementById('repeat_password');
    const username = document.getElementById('username');
    const phoneNumber = document.getElementById('phone_number');
    const phonePattern = /\d{2,3}-\d{3,4}-\d{4}$/;

    if (password.value.length < 8) {
        alert('비밀번호는 최소 8자리여야 합니다.');
        password.focus();
        return false;
    } else if (password.value.length > 20) {
        alert('비밀번호는 최대 20자리여야 합니다.');
        password.focus();
        return false;
    } else if (password.value !== repeatPassword.value) {
        alert('비밀번호가 일치하지 않습니다.');
        password.focus();
        return false;
    }

    if (username.value.trim() === '') {
        alert('이름을 입력하세요.');
        username.focus();
        return false;
    } else if (username.value.length > 25) {
        alert('이름은 25자 이내로 작성해야 합니다.');
        username.focus();
        return false;
    }

    if (phoneNumber.value !== "" && !phonePattern.test(phoneNumber.value)) {
        alert('연락처 형식이 올바르지 않습니다.');
        phoneNumber.focus();
        return false;
    }

    if (confirm('저장하시겠습니까?')) {
        document.getElementById('form_userInfo').submit();
    }
}

function confirmDeletion() {
    if (confirm("회원탈퇴 하시겠습니까?"))
        location.href = "/user/delete";
}