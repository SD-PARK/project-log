function setFavorites(element) {
    const input = document.getElementById('favorites');

    if (input.value === 'true') {
        input.value = 'false';
        element.innerText = '☆';
    } else {
        input.value = 'true';
        element.innerText = '★';
    }
}

function validate() {
    const name = document.getElementById("name");
    const phoneNumber = document.getElementById("phone_number");
    const favorites = document.getElementById("favorites");
    const memo = document.getElementById("memo");
    const phonePattern = /\d{2,3}-\d{3,4}-\d{4}$/;

    if (name.value.trim() === '') {
        alert('이름을 입력하세요.');
        return false;
    } else if (name.value.length > 25) {
        alert('이름은 25자 이내로 작성해야 합니다.');
        return false;
    }

    if (favorites.value != 'true' && favorites.value != 'false') {
        favorites.value = 'false';
    }

    if (memo.value.length > 1000) {
        alert('메모는 1000자 이내로 작성해야 합니다.');
        return false;
    }

    if (!phonePattern.test(phoneNumber.value)) {
        alert('연락처 형식이 올바르지 않습니다.');
        phoneNumber.focus();
        return false;
    }

    return true;
}

function saveContact() {
    if (validate() && confirm('저장하시겠습니까?')) {
		const contactId = document.getElementById("contact_id");
    	if (contactId.value == "") contactId.value = -1;
    	
        const form = document.getElementById("contact-form");
        form.submit();
    }
}

function deleteContact() {
    if (confirm('삭제하시겠습니까?')) {
        const contactId = document.getElementById("contact_id").value;

        if (contactId) {
            location.href = `/contact/delete/${contactId}`;
        } else {
            location.href = `/`;
        }
    }
}