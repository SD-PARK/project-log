document.addEventListener('DOMContentLoaded', function() {
    const groupInputs = document.querySelectorAll('.group_name');
    groupInputs.forEach(input => {
        input.addEventListener('blur', e => handleInputBlur(e.target));
    });
});

function validateGroupName(groupName) {
    if (groupName.trim() !== "" && groupName.length <= 30)
        return true;
    else {
        alert("그룹 명은 1~30자 이내로 작성해야합니다.");
        return false;
    }
}

function handleInputBlur(input) {
    if (!validateGroupName(input.value))
        return false;

    const groupId = encodeURIComponent(input.getAttribute('data-group-id'));
    const groupName = encodeURIComponent(input.value);

    location.href = `/group/update?groupId=${groupId}&groupName=${groupName}`;
}

function handleNewInputBlur(input) {
    if (!validateGroupName(input.value))
        return false;

    const groupName = encodeURIComponent(input.value);

    location.href = `/group/add?groupName=${groupName}`;
}

function createGroup() {
    const newGroupDiv = document.createElement('div');
    newGroupDiv.className = 'groups';
    newGroupDiv.innerHTML = `
        <div class="group-div">
            <input type="text" name="group_name" class="group_name" value="" placeholder="그룹명을 입력하세요" onkeyup="checkEnter(event, this)" />
        </div>
    `;

    document.getElementById('group-list').appendChild(newGroupDiv);

    const newInput = newGroupDiv.querySelector('.group_name');
    newInput.addEventListener('blur', function(event) {
        handleNewInputBlur(event.target);
    });

    newInput.focus();
}

function deleteGroup(groupId) {
    location.href = `/group/delete/${groupId}`;
}

function checkEnter(event, element) {
    if (event.key === "Enter") {
        element.blur();
    }
}