const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phonePattern = /\d{2,3}-\d{3,4}-\d{4}$/;

function checkEmailDuplicated() {
    const email = document.getElementById('email');
    
    if (validateEmail(email.value))
        return false;

    const url = new URL(
        `/user/checkEmail?email=${encodeURIComponent(email.value)}`,
        window.location.origin
    );

    fetch(url, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
    })
    .then(res => res.json())
    .then(data => {
        if (data.result) {
            alert("이 이메일은 이미 사용 중입니다.");
        } else {
            alert("사용 가능한 이메일입니다.");
            email.disabled = true;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function validateEmail(email) {
    if (!emailRegex.test(email)) {
        alert('유효한 이메일 주소를 입력하세요.');
        return true;
    }
    return false;
}

function validateForm() {
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const repeatPassword = document.getElementById('repeat_password');
    const username = document.getElementById('username');
    const phoneNumber = document.getElementById('phone_number');

    if (!email.disabled) {
        alert('이메일의 중복 여부를 검사해야 합니다.');
        email.focus();
        return false;
    }

    if (password.value.length < 8) {
        alert('비밀번호는 최소 8자리여야 합니다.');
        password.focus();
        return false;
    } else if (password.value.length > 20) {
        alert('비밀번호는 최대 20자리여야 합니다.');
        password.focus();
        return false;
    } else if (password.value !== repeatPassword.value) {
        alert('비밀번호가 일치하지 않습니다.');
        password.focus();
        return false;
    }

    if (username.value.trim() === '') {
        alert('이름을 입력하세요.');
        username.focus();
        return false;
    } else if (username.value.length > 25) {
        alert('이름은 25자 이내로 작성해야 합니다.');
        username.focus();
        return false;
    }

    if (phoneNumber.value !== "" && !phonePattern.test(phoneNumber.value)) {
        alert('연락처 형식이 올바르지 않습니다.');
        phoneNumber.focus();
        return false;
    }

    email.disabled = false;
    document.getElementById('form_sign').submit();
}