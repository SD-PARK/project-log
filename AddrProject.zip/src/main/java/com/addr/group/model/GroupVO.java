package com.addr.group.model;

import lombok.Data;

@Data
public class GroupVO {
	private int groupId;
	private int userId;
	private String groupName;
}