package com.addr.group.dao;

import java.util.List;

import com.addr.group.model.GroupVO;

public interface IGroupRepository {
	static boolean SUCCESS = true;
	static boolean FAILED = false;
	
	boolean addGroup(GroupVO addGroup);
	
	List<GroupVO> getGroups(int userId);
	
	boolean updateGroupName(GroupVO updateGroup);
	
	boolean deleteGroup(int groupId, int userId);
}