package com.addr.group.service;

import java.util.List;

import com.addr.group.model.GroupVO;

public interface IGroupService {
	boolean addGroup(int userId, GroupVO addGroup);
	
	List<GroupVO> getGroups(int userId);
	
	boolean updateGroupName(int userId, GroupVO updateGroup);
	
	boolean deleteGroup(int groupId, int userId);
}