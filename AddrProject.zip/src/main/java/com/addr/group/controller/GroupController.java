package com.addr.group.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.addr.group.dao.GroupRepository;
import com.addr.group.model.GroupVO;
import com.addr.group.service.IGroupService;
import com.addr.util.SessionUtil;

@Controller
public class GroupController {
	@Autowired
	IGroupService groupService;
	
	@GetMapping("/group")
	public String getGroupPage(final HttpServletRequest request, Model model) {
		int userId = SessionUtil.getSessionId(request);
		
		model.addAttribute("groups", groupService.getGroups(userId));
		
		return "/group/groups";
	}
	
	@GetMapping("/group/add")
	public String addGroup(GroupVO addData, final HttpServletRequest request) {
		int userId = SessionUtil.getSessionId(request);
		boolean result = groupService.addGroup(userId, addData);
		
		if (result == GroupRepository.FAILED)
			request.getSession().setAttribute("message", "그룹을 생성할 수 없습니다.");
		
		return "redirect:/group";
	}
	
	@GetMapping("/group/update")
	public String updateGroup(GroupVO updateData, final HttpServletRequest request) {
		int userId = SessionUtil.getSessionId(request);
		boolean result = groupService.updateGroupName(userId, updateData);
		
		if (result == GroupRepository.FAILED)
			request.getSession().setAttribute("message", "그룹 정보를 변경할 수 없습니다.");
		
		return "redirect:/group";
	}
	
	@GetMapping("/group/delete/{groupId}")
	public String deleteGroup(@PathVariable int groupId, final HttpServletRequest request) {
		int userId = SessionUtil.getSessionId(request);
		boolean result = groupService.deleteGroup(groupId, userId);
		
		if (result == GroupRepository.FAILED)
			request.getSession().setAttribute("message", "그룹을 삭제할 수 없습니다.");
		
		return "redirect:/group";
	}
}