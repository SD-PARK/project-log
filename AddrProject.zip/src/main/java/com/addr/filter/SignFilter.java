package com.addr.filter;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SignFilter implements Filter {
	private static final List<String> BEFORE_LOGIN_PAGES = List.of("/login", "/signup", "/user/checkEmail");
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpReq = (HttpServletRequest) request;
		HttpServletResponse httpRes = (HttpServletResponse) response;
		String path = httpReq.getServletPath();
		boolean sessionInvalid = isSessionInvalid(httpReq.getSession());
		boolean loginPage = isLoginPage(path);
		boolean staticFile = isStaticFile(path);
		
		if (sessionInvalid && !loginPage && !staticFile) {
			httpRes.sendRedirect("/login");
			return;
		}
		if (!sessionInvalid && loginPage && !staticFile) {
			httpRes.sendRedirect("/");
			return;
		}
		
		chain.doFilter(request, response);
	}
	
	private boolean isSessionInvalid(HttpSession session) {
		return session.isNew() || session.getAttribute("id") == null;
	}
	
	private boolean isLoginPage(String path) {
		return BEFORE_LOGIN_PAGES.contains(path);
	}
	
	private boolean isStaticFile(String path) {
		return (path.endsWith(".css") || path.endsWith(".js"));
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {}

	@Override
	public void destroy() {}
}
