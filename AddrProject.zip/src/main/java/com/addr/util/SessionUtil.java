package com.addr.util;

import javax.servlet.http.HttpSession;

public class SessionUtil {
	public static int getSessionId(HttpSession httpSession) {
		try {
			return (int) httpSession.getAttribute("id");
		} catch (Exception e) {
			return -1;
		}
	}
}