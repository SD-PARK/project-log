package com.addr.util;

import javax.servlet.http.HttpServletRequest;

public class SessionUtil {
	public static int getSessionId(HttpServletRequest request) {
		return (int) request.getSession().getAttribute("id");
	}
}