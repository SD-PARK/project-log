package com.addr.util;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {
    public static String hashPassword(String textPassword) {
        return BCrypt.hashpw(textPassword, BCrypt.gensalt());
    }

    public static boolean checkPassword(String textPassword, String hashedPassword) {
    	try {
            return BCrypt.checkpw(textPassword, hashedPassword);
    	} catch(Exception e) {
    		return false;
    	}
    }
}