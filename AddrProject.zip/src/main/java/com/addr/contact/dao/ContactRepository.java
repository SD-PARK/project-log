package com.addr.contact.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.addr.contact.model.ContactVO;
import com.addr.contact.model.ContactViewVO;
import com.addr.contact.model.UpdateFavoritesVO;

@Repository
public class ContactRepository implements IContactRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class ContactMapper implements RowMapper<ContactVO> {
		@Override
		public ContactVO mapRow(ResultSet rs, int count) throws SQLException {
			ContactVO contact = new ContactVO();
			contact.setContactId(rs.getInt("contact_id"));
			contact.setUserId(rs.getInt("user_id"));
			contact.setPhoneNumber(rs.getString("phone_number"));
			contact.setName(rs.getString("name"));
			contact.setGroupId(rs.getInt("group_id"));
			contact.setMemo(rs.getString("memo"));
			contact.setFavorites(rs.getBoolean("favorites"));
			return contact;
		}
	}
	
	private class ContactViewMapper implements RowMapper<ContactViewVO> {
		@Override
		public ContactViewVO mapRow(ResultSet rs, int count) throws SQLException {
			ContactViewVO view = new ContactViewVO();
			view.setContactId(rs.getInt("contact_id"));
			view.setName(rs.getString("name"));
			view.setGroupName(rs.getString("group_name"));
			view.setPhoneNumber(rs.getString("phone_number"));
			view.setFavorites(rs.getBoolean("favorites"));
			return view;
		}
	}
	
	@Override
	public boolean addContact(ContactVO contact) {
		Object groupId = (contact.getGroupId() > 0) ? contact.getGroupId() : null;
		String query = "INSERT INTO contacts (user_id, phone_number, name, group_id, memo, favorites)"
					 + " VALUES (?, ?, ?, ?, ?, ?)";
		
		boolean result = jdbcTemplate.update(query,
							contact.getUserId(),
							contact.getPhoneNumber(),
							contact.getName(),
							groupId,
							contact.getMemo(),
							contact.isFavorites()) > 0 ? SUCCESS : FAILED;
		
		return result;
	}

	@Override
	public ContactVO getContact(int contactId, int userId) {
		String query = "SELECT * FROM contacts WHERE contact_id = ? AND user_id = ?";
		ContactVO result = null;
		
		try {
			result = jdbcTemplate.queryForObject(query,
						new ContactMapper(),
						contactId, userId);
		} catch (IncorrectResultSizeDataAccessException e) {}
		
		return result;
	}

	@Override
	public List<ContactViewVO> getContactList(int userId) {
		String query = "SELECT contact_id, phone_number, name, favorites, "
					+ "(SELECT group_name FROM groups g WHERE g.group_id = c.group_id) as group_name "
					+ "FROM contacts c WHERE user_id = ? ORDER BY name ASC";
		
		List<ContactViewVO> result = jdbcTemplate.query(query,
										new ContactViewMapper(),
										userId);
		
		return result;
	}

	@Override
	public boolean updateContact(ContactVO updateContact) {
		Object groupId = (updateContact.getGroupId() > 0) ? updateContact.getGroupId() : null;
		String query = "UPDATE contacts SET phone_number = ?, name = ?, group_id = ?, memo = ?, favorites = ? "
					+ "WHERE contact_id = ? AND user_id = ?";
		
		boolean result = jdbcTemplate.update(query,
							updateContact.getPhoneNumber(),
							updateContact.getName(),
							groupId,
							updateContact.getMemo(),
							updateContact.isFavorites(),
							updateContact.getContactId(),
							updateContact.getUserId()) > 0 ? SUCCESS : FAILED;
		
		return result;
	}

	@Override
	public boolean updateFavoritesStatus(UpdateFavoritesVO updateData) {
		String query = "UPDATE contacts SET favorites = ? WHERE contact_id = ? AND user_id = ?";
		
		boolean result = jdbcTemplate.update(query,
							updateData.isFavorites(),
							updateData.getContactId(), 
							updateData.getUserId()) > 0 ? SUCCESS : FAILED;
		
		return result;
	}

	@Override
	public boolean deleteContact(int contactId, int userId) {
		String query = "DELETE FROM contacts WHERE contact_id = ? AND user_id = ?";
		
		boolean result = jdbcTemplate.update(query,
							contactId,
							userId) > 0 ? SUCCESS : FAILED;
		
		return result;
	}
}