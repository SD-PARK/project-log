package com.addr.contact.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;

import com.addr.contact.dao.ContactRepository;
import com.addr.contact.model.ContactVO;
import com.addr.contact.model.UpdateFavoritesVO;
import com.addr.contact.service.IContactService;
import com.addr.group.service.IGroupService;
import com.addr.util.SessionUtil;

@Controller
public class ContactController {
	@Autowired
	IContactService contactService;
	@Autowired
	IGroupService groupService;
	@Autowired
	HttpSession httpSession;
	
	@GetMapping("/")
	public String getMainPage(Model model) {
		int userId = SessionUtil.getSessionId(httpSession);
		
		model.addAttribute("contacts", contactService.getContactList(userId));
		
		return "/contact/main";
	}
	
	@GetMapping("/contact")
	public String getContactPage(Model model) {
		int userId = SessionUtil.getSessionId(httpSession);
		
		model.addAttribute("groups", groupService.getGroups(userId));
		
		return "/contact/contactInfo";
	}
	
	@GetMapping("/contact/{contactId}")
	public String getContactPage(@PathVariable int contactId, Model model) {
		int userId = SessionUtil.getSessionId(httpSession);
		
		model.addAttribute("contact", contactService.getContact(contactId, userId));
		model.addAttribute("groups", groupService.getGroups(userId));
		
		return "/contact/contactInfo";
	}
	
	@PostMapping("/contact")
	public String addOrUpdateContact(ContactVO contactData) {
		int userId = SessionUtil.getSessionId(httpSession);
		boolean result = contactService.addOrUpdateContact(userId, contactData);
		
		if (result == ContactRepository.FAILED)
			httpSession.setAttribute("message", "연락처 정보를 저장할 수 없습니다.");

		return "redirect:/";
	}
	
	@GetMapping("/contact/delete/{contactId}")
	public String deleteContact(@PathVariable("contactId") int contactId) {
		int userId = SessionUtil.getSessionId(httpSession);
		boolean result = contactService.deleteContact(contactId, userId);
		
		if (result == ContactRepository.FAILED)
			httpSession.setAttribute("message", "연락처를 삭제할 수 없습니다.");
        
		return "redirect:/";
	}
	
	@PostMapping("/contact/favorites")
	@ResponseBody
	public Map<String, Boolean> updateFavorites(
        @RequestBody UpdateFavoritesVO updateFavoritesVO,
        final HttpServletRequest request
	) {
		Map<String, Boolean> result = new HashMap<>();
		int userId = SessionUtil.getSessionId(httpSession);
		boolean isSuccess = contactService.updateFavoritesStatus(userId, updateFavoritesVO);
		
		result.put("result", isSuccess);
		return result;
	}
}