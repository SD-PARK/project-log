package com.addr.contact.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;

import com.addr.contact.dao.ContactRepository;
import com.addr.contact.model.ContactVO;
import com.addr.contact.model.UpdateFavoritesVO;
import com.addr.contact.service.IContactService;
import com.addr.group.service.IGroupService;
import com.addr.util.SessionUtil;

@Controller
public class ContactController {
	@Autowired
	IContactService contactService;
	@Autowired
	IGroupService groupService;
	
	@GetMapping("/")
	public String getMainPage(final HttpServletRequest request, Model model) {
		int userId = SessionUtil.getSessionId(request);
		
		model.addAttribute("contacts", contactService.getContactList(userId));
		
		return "/contact/main";
	}
	
	@GetMapping("/contact")
	public String getContactPage(final HttpServletRequest request, Model model) {
		int userId = SessionUtil.getSessionId(request);
		
		model.addAttribute("groups", groupService.getGroups(userId));
		
		return "/contact/contactInfo";
	}
	
	@GetMapping("/contact/{contactId}")
	public String getContactPage(@PathVariable int contactId, final HttpServletRequest request, Model model) {
		int userId = SessionUtil.getSessionId(request);
		
		model.addAttribute("contact", contactService.getContact(contactId, userId));
		model.addAttribute("groups", groupService.getGroups(userId));
		
		return "/contact/contactInfo";
	}
	
	@PostMapping("/contact")
	public String addOrUpdateContact(ContactVO contactData, final HttpServletRequest request) {
		int userId = SessionUtil.getSessionId(request);
		boolean result = contactService.addOrUpdateContact(userId, contactData);
		
		if (result == ContactRepository.FAILED)
			request.getSession().setAttribute("message", "연락처 정보를 저장할 수 없습니다.");

		return "redirect:/";
	}
	
	@GetMapping("/contact/delete/{contactId}")
	public String deleteContact(@PathVariable("contactId") int contactId, final HttpServletRequest request) {
		int userId = SessionUtil.getSessionId(request);
		boolean result = contactService.deleteContact(contactId, userId);
		
		if (result == ContactRepository.FAILED)
			request.getSession().setAttribute("message", "연락처를 삭제할 수 없습니다.");
        
		return "redirect:/";
	}
	
	@PostMapping("/contact/favorites")
	@ResponseBody
	public Map<String, Boolean> updateFavorites(
        @RequestBody UpdateFavoritesVO updateFavoritesVO,
        final HttpServletRequest request
	) {
		Map<String, Boolean> result = new HashMap<>();
		int userId = SessionUtil.getSessionId(request);
		boolean isSuccess = contactService.updateFavoritesStatus(userId, updateFavoritesVO);
		
		result.put("result", isSuccess);
		return result;
	}
}