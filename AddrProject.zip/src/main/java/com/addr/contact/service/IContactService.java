package com.addr.contact.service;

import java.util.List;

import com.addr.contact.model.ContactVO;
import com.addr.contact.model.ContactViewVO;
import com.addr.contact.model.UpdateFavoritesVO;

public interface IContactService {
	ContactVO getContact(int contactId, int userId);
	
	List<ContactViewVO> getContactList(int userId);
	
	boolean addOrUpdateContact(int userId, ContactVO contact);
	
	boolean updateFavoritesStatus(int userId, UpdateFavoritesVO updateData);
	
	boolean deleteContact(int contactId, int userId);
}