package com.addr.user.dao;

import com.addr.user.model.UserUpdateVO;
import com.addr.user.model.UserVO;

public interface IUserRepository {
	static boolean DUPLICATED = true;
	static boolean NOT_DUPLICATED = false;
	static boolean SUCCESS = true;
	static boolean FAILED = false;
	
	int addUser(UserVO user);
	
	UserVO getUser(int userId);
	
	UserVO getUserByEmail(String email);
	
	boolean updateUser(int userId, UserUpdateVO user);
	
	boolean deleteUser(int userId);
	
	boolean checkDuplicatedEmail(String email);
}