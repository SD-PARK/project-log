package com.addr.user.model;

import lombok.Data;

@Data
public class UserUpdateVO {
	private String password;
	private String username;
	private String phoneNumber;
}