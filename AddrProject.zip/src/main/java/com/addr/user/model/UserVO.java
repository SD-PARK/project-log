package com.addr.user.model;

import java.sql.Timestamp;
import lombok.Data;

@Data
public class UserVO {
	private int userId;
	private String email;
	private String password;
	private String username;
	private String phoneNumber;
	private Timestamp regdate;
}