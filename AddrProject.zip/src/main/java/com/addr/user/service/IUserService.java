package com.addr.user.service;

import com.addr.user.model.UserLoginVO;
import com.addr.user.model.UserUpdateVO;
import com.addr.user.model.UserVO;

public interface IUserService {
	int login(UserLoginVO loginData);
	
	boolean checkDuplicatedEmail(String email);
	
	UserVO getUser(int userId);
	
	int createUser(UserVO createData);
	
	boolean updateUser(int userId, UserUpdateVO updateData);
	
	boolean deleteUser(int userId);
}