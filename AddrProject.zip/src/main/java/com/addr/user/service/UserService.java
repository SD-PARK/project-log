package com.addr.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.addr.user.dao.IUserRepository;
import com.addr.user.model.UserLoginVO;
import com.addr.user.model.UserUpdateVO;
import com.addr.user.model.UserVO;
import com.addr.util.PasswordUtil;

@Service
public class UserService implements IUserService {
	@Autowired
	IUserRepository userRepository;
	
	@Override
	public int login(UserLoginVO loginData) {
		UserVO user = userRepository.getUserByEmail(loginData.getEmail());

		if (user != null && PasswordUtil.checkPassword(loginData.getPassword(), user.getPassword()))
			return user.getUserId();
		else
			return -1;
	}

	@Override
	public boolean checkDuplicatedEmail(String email) {
		return userRepository.checkDuplicatedEmail(email);
	}

	@Override
	public UserVO getUser(int userId) {
		return userRepository.getUser(userId);
	}

	@Override
	public int createUser(UserVO createData) {
		String hashedPassword = PasswordUtil.hashPassword(createData.getPassword());
		createData.setPassword(hashedPassword);
		
		return userRepository.addUser(createData);
	}

	@Override
	public boolean updateUser(int userId, UserUpdateVO updateData) {
		String hashedPassword = PasswordUtil.hashPassword(updateData.getPassword());
		updateData.setPassword(hashedPassword);
		
		return userRepository.updateUser(userId, updateData);
	}

	@Override
	public boolean deleteUser(int userId) {
		return userRepository.deleteUser(userId);
	}
}