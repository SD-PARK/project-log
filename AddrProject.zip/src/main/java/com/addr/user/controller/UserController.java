package com.addr.user.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.addr.user.dao.IUserRepository;
import com.addr.user.model.UserLoginVO;
import com.addr.user.model.UserUpdateVO;
import com.addr.user.model.UserVO;
import com.addr.user.service.IUserService;
import com.addr.util.SessionUtil;

@Controller
public class UserController {
	@Autowired
	IUserService userService;
	
	@GetMapping("/login")
	public String getLoginPage() {
		return "/user/login";
	}
	
	@PostMapping("/login")
	public String login(UserLoginVO loginData, final HttpServletRequest request) {
		int userId = userService.login(loginData);
		
		if (userId > 0) {
			request.getSession().setAttribute("id", userId);
			return "redirect:/";
		} else {
			request.getSession().setAttribute("message", "로그인에 실패했습니다.");
			return "/user/login";
		}
	}
	
	@GetMapping("/logout")
	public String logout(final HttpServletRequest request) {
		request.getSession().invalidate();
		return "redirect:/login";
	}
	
	@GetMapping("/signup")
	public String getSignupPage() {
		return "/user/signup";
	}
	
	@PostMapping("/signup")
	public String signup(UserVO signupData, final HttpServletRequest request) {
		int userId = userService.createUser(signupData);
		
		if (userId > 0) {
			request.getSession().setAttribute("id", userId);
			return "redirect:/";
		} else {
			request.getSession().setAttribute("message", "회원가입에 실패했습니다.");
			return "/user/signup";
		}
	}
	
	@GetMapping("/mypage")
	public String getUserPage(final HttpServletRequest request, Model model) {
		int userId = SessionUtil.getSessionId(request);
		
		model.addAttribute("user", userService.getUser(userId));
		
		return "/user/mypage";
	}
	
	@PostMapping("/user/update")
	public String updateUser(UserUpdateVO updateData, final HttpServletRequest request, Model model) {
		int userId = SessionUtil.getSessionId(request);
		boolean result = userService.updateUser(userId, updateData);
		
		if (result == IUserRepository.FAILED)
			request.getSession().setAttribute("message", "회원 정보를 저장할 수 없습니다.");
		
		return "redirect:/mypage";
	}
	
	@GetMapping("/user/delete")
	public String deleteUser(final HttpServletRequest request, Model model) {
		int userId = SessionUtil.getSessionId(request);
		boolean result = userService.deleteUser(userId);
		
		if (result == IUserRepository.FAILED)
			request.getSession().setAttribute("message", "회원 탈퇴에 실패했습니다.");

		return "redirect:/logout";
	}
	
	@GetMapping("/user/checkEmail")
	@ResponseBody
	public Map<String, Boolean> checkDuplicatedEmail(@RequestParam String email) {
		Map<String, Boolean> result = new HashMap<>();
		boolean isDuplicated = userService.checkDuplicatedEmail(email);
		
		result.put("result", isDuplicated);
		return result;
	}
}