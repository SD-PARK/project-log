function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}

document.addEventListener('DOMContentLoaded', () => {
    const alertBox = document.getElementById("alert-box");
    const timeSpan = alertBox.querySelector(".time");

    alertBox.style.display = 'block';
    alertBox.style.opacity = 0.8;

    let countdown = 3;

    timeSpan.textContent = countdown;
    const interval = setInterval(() => {
        timeSpan.textContent = --countdown;
        if (countdown <= 0) {
            clearInterval(interval);
            alertBox.style.opacity = 0;
            setTimeout(() => {
                alertBox.style.display = 'none';
            }, 600);
        }
    }, 1000);
});