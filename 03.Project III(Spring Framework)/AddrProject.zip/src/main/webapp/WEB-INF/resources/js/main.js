function toggleFavorite(element) {
    let url = '/contact/favorites';
    
    const data = {
    	contactId: element.value,
    	favorites: (element.innerText === '☆') ? true : false
    };

    fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(data => {
        if (data.result) {
            const contact = contacts.find(contact => contact.contactId === element.value);
            contact.favorites = !contact.favorites;
            handleKeyword();
        } else {
            alert("즐겨찾기 여부를 변경하지 못했습니다.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function checkEnter(event) {
    if (event.key === "Enter") {
        document.getElementById("keyword-button").click();
    }
}

function toContactInfo(id) {
    let url = `/contact/${encodeURIComponent(id)}`;
    location.href = url;
}

function search(keyword = document.getElementById("keyword").value.split('-').join('').toLowerCase()) {
    const filteredContacts = contacts.filter(contact => {
        return contact.name.toLowerCase().includes(keyword) ||
               contact.phoneNumber.split('-').join('').includes(keyword);
    });

    setCookie('keyword', keyword);
    renderContacts(filteredContacts);
}

function renderContacts(filteredContacts) {
    const favoritesContent = document.getElementById("favorites-content");
    const contactsContent = document.getElementById("contacts-content");
    favoritesContent.innerHTML = '';
    contactsContent.innerHTML = '';

    filteredContacts.forEach(contact => {
        const contactDiv = document.createElement('div');
        contactDiv.className = 'contact';
        contactDiv.onclick = () => toContactInfo(contact.contactId);

        const nameDiv = document.createElement('div');
        nameDiv.className = 'name';
        nameDiv.textContent = contact.name;

        const groupDiv = document.createElement('div');
        groupDiv.className = 'group';
        groupDiv.textContent = contact.groupName;

        const starButton = document.createElement('button');
        starButton.className = 'star';
        starButton.value = contact.contactId;
        starButton.onclick = (event) => {
            event.stopPropagation();
            toggleFavorite(starButton);
        };
        starButton.textContent = contact.favorites ? '★' : '☆';

        contactDiv.appendChild(nameDiv);
        contactDiv.appendChild(groupDiv);
        contactDiv.appendChild(starButton);

        if (contact.favorites) {
            favoritesContent.appendChild(contactDiv);
        } else {
            contactsContent.appendChild(contactDiv);
        }
    });
}

function handleKeyword() {
    const keyword = getCookie('keyword');

    if (keyword == null || keyword == "") {
        renderContacts(contacts);
    } else {
        document.getElementById("keyword").value = keyword;
        search(keyword);
    }
}

document.addEventListener('DOMContentLoaded', handleKeyword);