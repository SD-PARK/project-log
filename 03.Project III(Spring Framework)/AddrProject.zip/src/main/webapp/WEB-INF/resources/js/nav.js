function goToMain() {
    location.href = '/';
}

function goToContactInfo() {
    location.href = '/contact';
}

function goToGroup() {
    location.href = '/group';
}

function goToMypage() {
    location.href = '/mypage';
}

function goToBoard() {
    location.href = '/home';
}

function goToLogout() {
    location.href = '/logout';
}