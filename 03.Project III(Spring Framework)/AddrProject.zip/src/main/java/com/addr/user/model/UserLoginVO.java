package com.addr.user.model;

import lombok.Data;

@Data
public class UserLoginVO {
	private String email;
	private String password;
}
