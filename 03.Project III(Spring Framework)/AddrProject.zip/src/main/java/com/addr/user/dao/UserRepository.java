package com.addr.user.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.addr.user.model.UserUpdateVO;
import com.addr.user.model.UserVO;

@Repository
public class UserRepository implements IUserRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class UserMapper implements RowMapper<UserVO> {
		@Override
		public UserVO mapRow(ResultSet rs, int count) throws SQLException {
			UserVO user = new UserVO();
			user.setUserId(rs.getInt("user_id"));
			user.setEmail(rs.getString("email"));
			user.setPassword(rs.getString("password"));
			user.setUsername(rs.getString("username"));
			user.setPhoneNumber(rs.getString("phone_number"));
			user.setRegdate(rs.getTimestamp("regdate"));
			return user;
		}
	}
	
	@Override
	public int addUser(UserVO user) {
		String query = "INSERT INTO users (email, password, username, phone_number)"
					 + "VALUES (?, ?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();
        
        jdbcTemplate.update(connection -> {
            PreparedStatement pstmt = connection.prepareStatement(query, new String[] {"user_id"});
    		pstmt.setString(1, user.getEmail());
    		pstmt.setString(2, user.getPassword());
    		pstmt.setString(3, user.getUsername());
    		pstmt.setString(4, user.getPhoneNumber());
            return pstmt;
        }, keyHolder);

		return keyHolder.getKey().intValue();
	}

	@Override
	public UserVO getUser(int userId) {
		String query = "SELECT * FROM users WHERE user_id = ?";
		UserVO result = null;
		
		try {
			result = jdbcTemplate.queryForObject(query,
						new UserMapper(),
						userId);
		} catch (IncorrectResultSizeDataAccessException e) {}
		
		return result;
	}

	@Override
	public UserVO getUserByEmail(String email) {
		String query = "SELECT user_id, password FROM users WHERE email LIKE ?";
		UserVO result = null;
		
		try {
			result = jdbcTemplate.queryForObject(query,
							(rs, count) -> {
								UserVO user = new UserVO();
								user.setUserId(rs.getInt("user_id"));
								user.setPassword(rs.getString("password"));
								return user;
							}, email);
		} catch (IncorrectResultSizeDataAccessException e) {}
		
		return result;
	}

	@Override
	public boolean updateUser(int userId, UserUpdateVO user) {
		String query = "UPDATE users SET password = ?, username = ?, phone_number = ? WHERE user_id = ?";
		
		boolean result = jdbcTemplate.update(query,
							user.getPassword(),
							user.getUsername(),
							user.getPhoneNumber(),
							userId) > 0 ? SUCCESS : FAILED;
		
		return result;
	}

	@Override
	public boolean deleteUser(int userId) {
		String query = "DELETE FROM users WHERE user_id = ?";
		
		boolean result = jdbcTemplate.update(query,
							userId) > 0 ? SUCCESS : FAILED;
		
		return result;
	}

	@Override
	public boolean checkDuplicatedEmail(String email) {
		String query = "SELECT 1 FROM users WHERE email LIKE ?";
		boolean result = DUPLICATED;
		
		try {
			jdbcTemplate.queryForObject(query, Integer.class, email);
		} catch (IncorrectResultSizeDataAccessException e) {
			result = NOT_DUPLICATED;
		}
		
		return result;
	}
}