package com.addr.contact.model;

import lombok.Data;

@Data
public class ContactVO {
	private int contactId = -1;
	private int userId = -1;
	private String phoneNumber;
	private String name;
	private int groupId = -1;
	private String memo;
	private boolean favorites = false;
}