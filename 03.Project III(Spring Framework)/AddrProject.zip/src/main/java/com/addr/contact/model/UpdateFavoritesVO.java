package com.addr.contact.model;

import lombok.Data;

@Data
public class UpdateFavoritesVO {
	private int contactId = -1;
	private int userId = -1;
	private boolean favorites = false;
}