package com.addr.contact.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.addr.contact.dao.IContactRepository;
import com.addr.contact.model.ContactVO;
import com.addr.contact.model.ContactViewVO;
import com.addr.contact.model.UpdateFavoritesVO;

@Service
public class ContactService implements IContactService {
	@Autowired
	IContactRepository contactRepository;

	@Override
	public ContactVO getContact(int contactId, int userId) {
		return contactRepository.getContact(contactId, userId);
	}

	@Override
	public List<ContactViewVO> getContactList(int userId) {
		return contactRepository.getContactList(userId);
	}

	@Override
	public boolean addOrUpdateContact(int userId, ContactVO contactData) {
		contactData.setUserId(userId);
		
		if (contactData.getContactId() > 0) {
			return contactRepository.updateContact(contactData);
		} else {
			return contactRepository.addContact(contactData);
		}
	}

	@Override
	public boolean updateFavoritesStatus(int userId, UpdateFavoritesVO updateData) {
		updateData.setUserId(userId);
		
		return contactRepository.updateFavoritesStatus(updateData);
	}

	@Override
	public boolean deleteContact(int contactId, int userId) {
		return contactRepository.deleteContact(contactId, userId);
	}
}
