package com.addr.contact.model;

import lombok.Data;

@Data
public class ContactViewVO {
	private int contactId;
	private String name;
	private String groupName;
	private String phoneNumber;
	private boolean favorites;
}
