package com.addr.contact.dao;

import java.util.List;

import com.addr.contact.model.ContactVO;
import com.addr.contact.model.ContactViewVO;
import com.addr.contact.model.UpdateFavoritesVO;

public interface IContactRepository {
	static boolean SUCCESS = true;
	static boolean FAILED = false;
	static boolean ACCESSIBLE = true;
	static boolean INACCESSIBLE = false;
	
	boolean addContact(ContactVO contact);
	
	ContactVO getContact(int contactId, int userId);
	
	List<ContactViewVO> getContactList(int userId);
	
	boolean updateContact(ContactVO updateContact);
	
	boolean updateFavoritesStatus(UpdateFavoritesVO updateData);
	
	boolean deleteContact(int contactId, int userId);
}
