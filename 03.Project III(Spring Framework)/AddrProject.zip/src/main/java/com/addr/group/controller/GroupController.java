package com.addr.group.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.addr.group.dao.GroupRepository;
import com.addr.group.model.GroupVO;
import com.addr.group.service.IGroupService;
import com.addr.util.SessionManager;

@Controller
public class GroupController {
	@Autowired
	IGroupService groupService;
	@Autowired
	SessionManager sessionManager;
	
	@GetMapping("/group")
	public String getGroupPage(Model model) {
		int userId = sessionManager.getSessionId();
		
		model.addAttribute("groups", groupService.getGroups(userId));
		
		return "/group/groups";
	}
	
	@GetMapping("/group/add")
	public String addGroup(GroupVO addData) {
		int userId = sessionManager.getSessionId();
		boolean result = groupService.addGroup(userId, addData);
		
		if (result == GroupRepository.FAILED)
			sessionManager.setSession("message", "그룹을 생성할 수 없습니다.");
		
		return "redirect:/group";
	}
	
	@GetMapping("/group/update")
	public String updateGroup(GroupVO updateData) {
		int userId = sessionManager.getSessionId();
		boolean result = groupService.updateGroupName(userId, updateData);
		
		if (result == GroupRepository.FAILED)
			sessionManager.setSession("message", "그룹 정보를 변경할 수 없습니다.");
		
		return "redirect:/group";
	}
	
	@GetMapping("/group/delete/{groupId}")
	public String deleteGroup(@PathVariable int groupId) {
		int userId = sessionManager.getSessionId();
		boolean result = groupService.deleteGroup(groupId, userId);
		
		if (result == GroupRepository.FAILED)
			sessionManager.setSession("message", "그룹을 삭제할 수 없습니다.");
		
		return "redirect:/group";
	}
}