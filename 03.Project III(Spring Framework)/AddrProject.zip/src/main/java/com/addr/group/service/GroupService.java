package com.addr.group.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.addr.group.dao.IGroupRepository;
import com.addr.group.model.GroupVO;

@Service
public class GroupService implements IGroupService {
	@Autowired
	IGroupRepository groupRepository;
	
	@Override
	public boolean addGroup(int userId, GroupVO addGroup) {
		addGroup.setUserId(userId);
		
		return groupRepository.addGroup(addGroup);
	}

	@Override
	public List<GroupVO> getGroups(int userId) {
		return groupRepository.getGroups(userId);
	}

	@Override
	public boolean updateGroupName(int userId, GroupVO updateGroup) {
		updateGroup.setUserId(userId);
		
		return groupRepository.updateGroupName(updateGroup);
	}

	@Override
	public boolean deleteGroup(int groupId, int userId) {
		return groupRepository.deleteGroup(groupId, userId);
	}
}