package com.addr.group.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.addr.group.model.GroupVO;

@Repository
public class GroupRepository implements IGroupRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class GroupMapper implements RowMapper<GroupVO> {
		@Override
		public GroupVO mapRow(ResultSet rs, int count) throws SQLException {
			GroupVO group = new GroupVO();
			group.setGroupId(rs.getInt("group_id"));
			group.setUserId(rs.getInt("user_id"));
			group.setGroupName(rs.getString("group_name"));
			return group;
		}
	}
	
	@Override
	public boolean addGroup(GroupVO addGroup) {
		String query = "INSERT INTO groups (user_id, group_name) VALUES (?, ?)";
		
		boolean result = jdbcTemplate.update(query,
							addGroup.getUserId(),
							addGroup.getGroupName()) > 0 ? SUCCESS : FAILED;
		
		return result;
	}

	@Override
	public List<GroupVO> getGroups(int userId) {
		String query = "SELECT * FROM groups WHERE user_id = ?";
		
		List<GroupVO> result = jdbcTemplate.query(query,
									new GroupMapper(),
									userId);
		
		return result;
	}

	@Override
	public boolean updateGroupName(GroupVO updateGroup) {
		String query = "UPDATE groups SET group_name = ? WHERE group_id = ? AND user_id = ?";
		
		boolean result = jdbcTemplate.update(query,
							updateGroup.getGroupName(),
							updateGroup.getGroupId(),
							updateGroup.getUserId()) > 0 ? SUCCESS : FAILED;
		
		return result;
	}

	@Override
	public boolean deleteGroup(int groupId, int userId) {
		String query = "DELETE FROM groups WHERE group_id = ? AND user_id = ?";
		
		boolean result = jdbcTemplate.update(query,
							groupId,
							userId) > 0 ? SUCCESS : FAILED;
		
		return result;
	}
}