package com.addr.util;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SessionManager {
	@Autowired
	HttpSession httpSession;
	
	public int getSessionId() {
		try {
			return (int) httpSession.getAttribute("id");
		} catch (Exception e) {
			return -1;
		}
	}
	
	public void setSession(String name, Object value) {
		httpSession.setAttribute(name, value);
	}
	
	public void invalidate() {
		httpSession.invalidate();
	}
}